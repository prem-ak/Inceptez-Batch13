### Refer to the "data_sales" file and come up with observations.

#### E.g. Yanaki is the most sold product.