## Exercise 01 for Class 02

#### Generate a dataset (Ensure that the data follows a normal distribution) and draw a frequency versus a normal distribution graph.

(Normal distribution to be plotted in a separate axis)