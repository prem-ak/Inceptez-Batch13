# IDS13

## Inceptez DataScience Batch 13 Course Material

---

The course files are arranged in folders as per the course flow. 
E.g. Class01 folder will have course material taught in Class 1 and the related exercise files 

## Download Instructions

1. Install git in your computer from https://git-scm.com/downloads
(A successfull installation of git would return a set of commands when typed `git` and pressed `enter` in the command prompt window)
2. Create a folder in your local drive e.g. DataScienceTraining
3. Navigate to the folder via command prompt
4. Enter the command `git clone https://github.com/hazeez/IDS13.git`
5. The files will be downloaded in your local machine and can be accessed by navigating to the folder.

